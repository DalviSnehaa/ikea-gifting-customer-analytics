-- Create a typed analysis table.
-- Date parsing supports common Online Retail II export formats:
-- M/D/YYYY H:MI and YYYY-MM-DD [HH:MI:SS].
-- Inspect any rows that fail conversion; adjust masks if your export differs.

DROP TABLE IF EXISTS retail.retail_cleaned;

CREATE TABLE retail.retail_cleaned AS
SELECT
    NULLIF(BTRIM(invoice), '') AS invoice,
    NULLIF(BTRIM(stockcode), '') AS stockcode,
    NULLIF(BTRIM(description), '') AS description,

    CASE
        WHEN BTRIM(quantity) ~ '^-?[0-9]+$'
        THEN BTRIM(quantity)::INTEGER
        ELSE NULL
    END AS quantity,

    CASE
        WHEN BTRIM(invoice_date) ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}'
        THEN BTRIM(invoice_date)::TIMESTAMP
        WHEN BTRIM(invoice_date) ~ '^[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}'
        THEN TO_TIMESTAMP(BTRIM(invoice_date), 'FMMM/FMDD/YYYY FMHH24:FMMI')::TIMESTAMP
        ELSE NULL
    END AS invoice_date,

    CASE
        WHEN BTRIM(price) ~ '^-?[0-9]+([.][0-9]+)?$'
        THEN BTRIM(price)::NUMERIC(12,2)
        ELSE NULL
    END AS price,

    CASE
        WHEN BTRIM(customer_id) ~ '^[0-9]+([.]0+)?$'
        THEN BTRIM(customer_id)::NUMERIC(20,2)::BIGINT
        ELSE NULL
    END AS customer_id,

    NULLIF(BTRIM(country), '') AS country

FROM retail.retail_combined;

-- Inspect rows where conversions did not succeed.
SELECT *
FROM retail.retail_cleaned
WHERE quantity IS NULL
   OR invoice_date IS NULL
   OR price IS NULL
LIMIT 100;

-- Create a convenience view of rows with key fields present.
-- This does not automatically remove returns / negative quantities.
CREATE OR REPLACE VIEW retail.retail_ready_for_review AS
SELECT *
FROM retail.retail_cleaned
WHERE invoice IS NOT NULL
  AND stockcode IS NOT NULL
  AND invoice_date IS NOT NULL
  AND price IS NOT NULL
  AND quantity IS NOT NULL;
