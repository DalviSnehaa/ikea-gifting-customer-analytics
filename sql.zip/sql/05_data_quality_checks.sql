-- Run these checks and record the results in your project notes.

-- Overall row count
SELECT COUNT(*) AS row_count FROM retail.retail_cleaned;

-- Missing customer identifiers
SELECT COUNT(*) AS missing_customer_id
FROM retail.retail_cleaned
WHERE customer_id IS NULL;

-- Zero or negative quantities (review returns / credit notes before excluding)
SELECT
    COUNT(*) FILTER (WHERE quantity = 0) AS zero_quantity_rows,
    COUNT(*) FILTER (WHERE quantity < 0) AS negative_quantity_rows
FROM retail.retail_cleaned;

-- Missing descriptions
SELECT COUNT(*) AS missing_description
FROM retail.retail_cleaned
WHERE description IS NULL OR BTRIM(description) = '';

-- Missing price / date / quantity after conversion
SELECT
    COUNT(*) FILTER (WHERE price IS NULL) AS invalid_or_missing_price,
    COUNT(*) FILTER (WHERE invoice_date IS NULL) AS invalid_or_missing_invoice_date,
    COUNT(*) FILTER (WHERE quantity IS NULL) AS invalid_or_missing_quantity
FROM retail.retail_cleaned;

-- Exact duplicate rows
SELECT
    invoice, stockcode, description, quantity, invoice_date,
    price, customer_id, country, COUNT(*) AS duplicate_count
FROM retail.retail_cleaned
GROUP BY
    invoice, stockcode, description, quantity, invoice_date,
    price, customer_id, country
HAVING COUNT(*) > 1
ORDER BY duplicate_count DESC;

-- Distinct invoices, customers, and countries
SELECT
    COUNT(DISTINCT invoice) AS distinct_invoices,
    COUNT(DISTINCT customer_id) AS distinct_customers,
    COUNT(DISTINCT country) AS distinct_countries
FROM retail.retail_cleaned;
