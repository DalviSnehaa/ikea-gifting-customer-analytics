-- Create staging tables before importing the two CSV exports in pgAdmin.
-- Import source columns as TEXT first; this preserves inconsistent values for validation.
CREATE TABLE IF NOT EXISTS retail.year_2009_2010 (
    invoice       TEXT,
    stockcode     TEXT,
    description   TEXT,
    quantity      TEXT,
    invoice_date  TEXT,
    price         TEXT,
    customer_id   TEXT,
    country       TEXT
);

CREATE TABLE IF NOT EXISTS retail.year_2010_2011 (
    invoice       TEXT,
    stockcode     TEXT,
    description   TEXT,
    quantity      TEXT,
    invoice_date  TEXT,
    price         TEXT,
    customer_id   TEXT,
    country       TEXT
);

-- After creating the tables, use pgAdmin Import/Export to load each yearly CSV.
-- Ensure the CSV column order matches the table definition.
