-- Consolidate both yearly staging tables.
DROP TABLE IF EXISTS retail.retail_combined;

CREATE TABLE retail.retail_combined AS
SELECT * FROM retail.year_2009_2010
UNION ALL
SELECT * FROM retail.year_2010_2011;

-- Basic source profiling
SELECT COUNT(*) AS combined_row_count
FROM retail.retail_combined;

SELECT COUNT(*) AS year_2009_2010_rows
FROM retail.year_2009_2010;

SELECT COUNT(*) AS year_2010_2011_rows
FROM retail.year_2010_2011;
