-- Run while connected to the ikea_customer_analytics database.
CREATE SCHEMA IF NOT EXISTS retail;
